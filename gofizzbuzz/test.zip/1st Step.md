## 1st Step: FizzBuzz
- Output numbers 1~100 to stdout (console).
- When the number is multiple of "3", print "Fizz" instead of the number.
- When the number is multiple of "5", print "Buzz" instead of the number.
- When the number is multiple of "3" and "5", print "FizzBuzz" instead of the number.